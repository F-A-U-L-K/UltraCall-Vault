#!/bin/bash
set -e

echo "============================================"
echo "  WebToAPK - Termux Setup"  
echo "  Build Android APKs on your phone!"
echo "============================================"
echo ""

# Update packages
echo "📦 Updating Termux packages..."
pkg update -y
pkg upgrade -y

# Install required packages
echo "📦 Installing Java & build tools..."
pkg install -y openjdk-17 wget unzip

# Set JAVA_HOME
export JAVA_HOME=$PREFIX/opt/openjdk
export PATH=$PATH:$JAVA_HOME/bin

echo "✅ Java installed: $(java -version 2>&1 | head -1)"

# Install Android SDK
SDK_DIR="$HOME/android-sdk"
if [ ! -d "$SDK_DIR/cmdline-tools/latest" ]; then
    echo ""
    echo "📥 Downloading Android SDK command-line tools..."
    mkdir -p "$SDK_DIR/cmdline-tools"
    
    wget -q --show-progress -O /tmp/cmdline-tools.zip \
        "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
    
    unzip -q -o /tmp/cmdline-tools.zip -d "$SDK_DIR/cmdline-tools/"
    mv "$SDK_DIR/cmdline-tools/cmdline-tools" "$SDK_DIR/cmdline-tools/latest" 2>/dev/null || true
    rm /tmp/cmdline-tools.zip
fi

export ANDROID_HOME="$SDK_DIR"
export PATH="$PATH:$SDK_DIR/cmdline-tools/latest/bin:$SDK_DIR/platform-tools"

echo "📦 Installing Android SDK packages..."
yes | sdkmanager --licenses >/dev/null 2>&1 || true
sdkmanager "platforms;android-34" \
           "build-tools;34.0.0" \
           "platform-tools"

echo ""
echo "✅ Setup complete!"
echo ""
echo "Add these to ~/.bashrc:"
echo '  export JAVA_HOME=$PREFIX/opt/openjdk'
echo '  export ANDROID_HOME=$HOME/android-sdk'  
echo '  export PATH=$PATH:$JAVA_HOME/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools'
echo ""
echo "Now run: bash build.sh"
echo ""
