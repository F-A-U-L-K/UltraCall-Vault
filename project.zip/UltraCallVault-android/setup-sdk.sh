#!/bin/bash
set -e

echo "📦 Setting up Android SDK..."

SDK_DIR="$HOME/android-sdk"
mkdir -p "$SDK_DIR/cmdline-tools"

# Detect OS
OS=""
case "$(uname -s)" in
    Linux*)  OS="linux";;
    Darwin*) OS="mac";;
    *)       echo "❌ Unsupported OS. Use Linux or Mac."; exit 1;;
esac

# Detect architecture for Termux
ARCH=$(uname -m)
echo "OS: $OS, Architecture: $ARCH"

echo "📥 Downloading Android command-line tools..."
TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-${OS}-11076708_latest.zip"
wget -q --show-progress -O /tmp/cmdline-tools.zip "$TOOLS_URL" || curl -L -o /tmp/cmdline-tools.zip "$TOOLS_URL"

echo "📂 Extracting..."
unzip -q -o /tmp/cmdline-tools.zip -d "$SDK_DIR/cmdline-tools/"
mv "$SDK_DIR/cmdline-tools/cmdline-tools" "$SDK_DIR/cmdline-tools/latest" 2>/dev/null || true
rm /tmp/cmdline-tools.zip

export ANDROID_HOME="$SDK_DIR"
export PATH="$PATH:$SDK_DIR/cmdline-tools/latest/bin"

echo "📦 Installing SDK packages (this may take a few minutes)..."
yes | sdkmanager --licenses >/dev/null 2>&1 || true
sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools"

echo ""
echo "✅ Android SDK installed at: $SDK_DIR"
echo ""
echo "Add these to your ~/.bashrc or ~/.zshrc:"
echo "  export ANDROID_HOME=$SDK_DIR"
echo "  export PATH=\$PATH:\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools"
echo ""
