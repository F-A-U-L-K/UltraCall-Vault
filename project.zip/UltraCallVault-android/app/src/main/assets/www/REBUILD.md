# REBUILD.md — UltraCall Vault 2026

Complete rebuild instructions to recreate this app from scratch.

## Tech Stack
- React 18/19, TypeScript, Vite, TailwindCSS 4
- Zustand (state), Dexie.js (IndexedDB), date-fns, framer-motion, lucide-react, uuid

## NPM Dependencies
```bash
npm install zustand dexie date-fns framer-motion lucide-react uuid @types/uuid
```

## File Structure
```
src/
├── App.tsx                    # Main entry - orchestrates Legal → Setup → Main app
├── main.tsx                   # React root render
├── index.css                  # TailwindCSS + custom theme + animations
├── types/
│   └── index.ts               # Recording, AppState, PermissionState, SearchFilters interfaces
├── db/
│   ├── database.ts            # Dexie.js database schema
│   └── seed.ts                # 15 seed recordings with realistic transcripts
├── stores/
│   ├── appStore.ts            # Zustand persisted: legal/setup completion, active tab, recording state
│   ├── permissionsStore.ts    # Zustand persisted: simulated permissions (mic, call_log, accessibility)
│   └── recordingsStore.ts     # Zustand: CRUD + filtering/sorting over Dexie
├── components/
│   ├── LegalModal.tsx         # Full-screen legal disclaimer. Checkbox + agree button. No scroll gate.
│   ├── SetupWizard.tsx        # 5-step wizard: Intro → Permissions → Test Call → Rules → Finish
│   ├── Dashboard.tsx          # Home: stats, call direction chart, "Simulate Call" button, recent list
│   ├── RecordingsList.tsx     # All recordings with direction icons, tags, source badges, actions
│   ├── RecordingDetail.tsx    # Waveform viz, synced transcript highlighting, AI summary, playback controls
│   ├── ForensicSearch.tsx     # Keyword search, direction/date/duration/tag filters, sort options
│   ├── BottomNav.tsx          # 4-tab bottom navigation with animated indicator
│   └── Settings.tsx           # App info, recording settings, permissions, storage, danger zone (reset)
index.html                     # Google Fonts (Orbitron + Inter), viewport meta
```

## Visual Identity
- Background: #000111
- Cyan accent: #00f5ff
- Purple accent: #a855f7
- Fonts: Orbitron (headings), Inter (body)
- Style: Neon Glassmorphism — glass-card with backdrop-blur, cyan/purple borders, glow effects

## Key Behaviors
1. **Legal Modal**: Full-screen disclaimer with 12 legal sections displayed in scrollable container. User checks a checkbox to confirm they've read the terms, then clicks "I Agree" button. NO scroll-to-bottom gate — checkbox and button are always accessible. Button is disabled only until checkbox is checked.
2. **Setup Wizard**: 5 steps. Permissions require all 3 grants (mic, call_log, accessibility). Test call simulates 3-second recording with animated waveform. Rules toggle auto-record and dual-path.
3. **Simulate Call**: Dashboard button triggers 8-15 second simulated recording with live waveform animation, then saves to Dexie with random contact/transcript.
4. **Forensic Search**: Fuzzy keyword across transcripts/contacts/tags/summaries. Duration range sliders, date pickers, tag multi-select, direction filter, sort by date/duration/name.
5. **Recording Detail**: 80-bar simulated waveform with playback progress. Synced transcript word highlighting. Copy transcript. AI summary card. Tag display. Export/Delete actions.
6. **15 Seed Recordings**: Generated on first launch with varied contacts, directions, durations (30-600s), transcripts, tags, and summaries.
7. **Settings**: Displays app version, recording config, permission status, storage stats with progress bar, and full reset capability.

## LegalModal.tsx — Exact Implementation
```tsx
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, AlertTriangle, Scale } from 'lucide-react';
import { useAppStore } from '../stores/appStore';

export function LegalModal() {
  const [agreed, setAgreed] = useState(false);
  const setHasCompletedLegal = useAppStore(s => s.setHasCompletedLegal);

  const handleAgree = () => {
    if (agreed) {
      setHasCompletedLegal(true);
    }
  };

  // Renders:
  // - Header with Shield icon, title "Legal Disclaimer", subtitle "UltraCall Vault 2026"
  // - Warning banner: "Please read and accept the agreement to proceed."
  // - Scrollable legal text (12 sections) — NO scroll gate
  // - Footer: checkbox (always enabled) + "I Agree — Enter UltraCall Vault" button (disabled until checkbox checked)
  // - Button uses className="neon-button w-full text-sm font-orbitron"
}
```

## Data Types (src/types/index.ts)
```ts
export interface Recording {
  id: string;
  callId: string;
  phoneNumber: string;
  contactName?: string;
  direction: 'incoming' | 'outgoing' | 'unknown';
  startTime: Date;
  endTime?: Date;
  durationSeconds?: number;
  audioFilePath: string;
  micFallbackPath?: string;
  transcript: string;
  tags: string[];
  isFavorite: boolean;
  sourceMethod: 'system' | 'microphone' | 'both';
  summary?: string;
}

export interface SearchFilters {
  keyword: string;
  direction: ('incoming' | 'outgoing' | 'unknown')[];
  dateFrom?: Date;
  dateTo?: Date;
  durationMin: number;
  durationMax: number;
  tags: string[];
  sortBy: 'date' | 'duration' | 'name';
  sortOrder: 'asc' | 'desc';
}
```

## Zustand Stores
- **appStore**: persisted to localStorage key 'ultracall-app'. Fields: hasCompletedLegal, hasCompletedSetup, activeTab ('home'|'recordings'|'search'|'settings'), isRecording, currentCallId.
- **permissionsStore**: persisted to localStorage key 'ultracall-permissions'. Fields: microphone, callLog, accessibility (all boolean).
- **recordingsStore**: non-persisted (reads from Dexie). Fields: recordings[], selectedRecording, loading. Actions: loadRecordings, addRecording, deleteRecording, toggleFavorite, setSelectedRecording.

## Dexie Database (src/db/database.ts)
- Database name: 'UltraCallVaultDB'
- Table: recordings with index on '&id, callId, phoneNumber, contactName, direction, startTime, *tags'

## Seed Data (src/db/seed.ts)
- 15 entries with varied contacts (Sarah Chen, Marcus Johnson, Dr. Emily Watson, Tech Support, Mom, Jake Rivera, Unknown, Amanda Foster, Legal Dept, David Kim, Pharmacy, Lisa Park, Robert Hayes, Client - Acme Corp, Emergency Services)
- Varied directions, durations (30-600s), source methods, tags, transcripts, and AI summaries
- Generated with dates spread across the last 14 days

## CSS Classes (index.css)
- `.glass-card`: bg-white/5, backdrop-blur-xl, border border-white/10, rounded-2xl
- `.neon-button`: bg-gradient-to-r from-vault-cyan to-vault-purple, text-black, font-bold, rounded-xl, shadow glow, disabled:opacity-30
- `.neon-button-outline`: border border-vault-cyan/50, text-vault-cyan, rounded-xl, hover bg-vault-cyan/10
- Custom scrollbar styling for webkit
- Tailwind theme extends: colors (vault-bg, vault-cyan, vault-purple, vault-text, vault-muted, vault-border, vault-card, vault-warning), fontFamily (orbitron, inter)
