#!/bin/bash
set -e

echo "============================================"
echo "  WebToAPK Builder - UltraCall Vault"
echo "============================================"
echo ""

# Check for Java
if ! command -v java &>/dev/null; then
    echo "❌ Java not found! Please install JDK 17:"
    echo "   Ubuntu/Debian: sudo apt install openjdk-17-jdk"
    echo "   Mac:           brew install openjdk@17"
    echo "   Termux:        pkg install openjdk-17"
    exit 1
fi

echo "✅ Java found: $(java -version 2>&1 | head -1)"

# Check for ANDROID_HOME or set it up
if [ -z "$ANDROID_HOME" ]; then
    if [ -d "$HOME/Android/Sdk" ]; then
        export ANDROID_HOME="$HOME/Android/Sdk"
    elif [ -d "$HOME/android-sdk" ]; then
        export ANDROID_HOME="$HOME/android-sdk"
    elif [ -d "/opt/android-sdk" ]; then
        export ANDROID_HOME="/opt/android-sdk"
    else
        echo ""
        echo "⚠️  Android SDK not found. Setting up automatically..."
        echo ""
        ./setup-sdk.sh
        export ANDROID_HOME="$HOME/android-sdk"
    fi
fi

export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/34.0.0"

echo "✅ Android SDK: $ANDROID_HOME"
echo ""
echo "🔨 Building debug APK..."
echo ""

# Use gradle wrapper or system gradle
if [ -f "./gradlew" ]; then
    chmod +x ./gradlew
    ./gradlew assembleDebug --no-daemon
else
    gradle assembleDebug --no-daemon
fi

echo ""
echo "============================================"

APK_PATH="app/build/outputs/apk/debug/"
if [ -d "$APK_PATH" ]; then
    APK_FILE=$(find "$APK_PATH" -name "*.apk" | head -1)
    if [ -n "$APK_FILE" ]; then
        SIZE=$(du -h "$APK_FILE" | cut -f1)
        echo "✅ BUILD SUCCESSFUL!"
        echo "📱 APK: $APK_FILE"
        echo "📏 Size: $SIZE"
        echo ""
        echo "To install on connected device:"
        echo "  adb install $APK_FILE"
        echo ""
        echo "Or copy the APK to your phone and open it."
        
        # Copy to project root for convenience
        cp "$APK_FILE" "./UltraCall_Vault.apk"
        echo "📦 Copied to: ./UltraCall_Vault.apk"
    else
        echo "❌ APK not found in output directory"
        exit 1
    fi
else
    echo "❌ Build output directory not found"
    exit 1
fi
echo "============================================"
