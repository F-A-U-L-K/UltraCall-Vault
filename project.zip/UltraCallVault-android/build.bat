@echo off
echo ============================================
echo   WebToAPK Builder - UltraCall Vault
echo ============================================
echo.

where java >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo X Java not found! Please install JDK 17 from:
    echo   https://adoptium.net/
    exit /b 1
)

echo OK Java found
java -version 2>&1 | findstr /i "version"

if not defined ANDROID_HOME (
    if exist "%LOCALAPPDATA%\Android\Sdk" (
        set ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk
    ) else if exist "%USERPROFILE%\AppData\Local\Android\Sdk" (
        set ANDROID_HOME=%USERPROFILE%\AppData\Local\Android\Sdk
    ) else (
        echo.
        echo WARNING: ANDROID_HOME not set. Please install Android SDK or Android Studio
        echo   Download: https://developer.android.com/studio
        echo   Or install command-line tools only
        exit /b 1
    )
)

echo OK Android SDK: %ANDROID_HOME%
echo.
echo Building debug APK...
echo.

if exist "gradlew.bat" (
    call gradlew.bat assembleDebug --no-daemon
) else (
    gradle assembleDebug --no-daemon
)

echo.
echo ============================================
echo BUILD COMPLETE!
echo APK location: app\build\outputs\apk\debug\
echo ============================================
