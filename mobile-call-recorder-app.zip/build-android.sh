#!/bin/bash
set -e

echo "🔨 Building UltraCall Vault..."

# Phase 1: Build Web
echo "📱 Building React web app..."
cd web
npm install --legacy-peer-deps
npm run build
cd ..

# Phase 2: Sync to Android
echo "📂 Syncing web dist to Android assets..."
rm -rf android/app/src/main/assets/*
cp -r web/dist/* android/app/src/main/assets/

# Phase 3: Build APK
echo "🎯 Building Android APK..."
cd android
./gradlew clean build --parallel
./gradlew assembleRelease
cd ..

echo "✅ Build complete!"
echo "📦 APK: android/app/build/outputs/apk/release/app-release.apk"
