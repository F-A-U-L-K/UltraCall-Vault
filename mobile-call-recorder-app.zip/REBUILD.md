# REBUILD.md — UltraCall Vault 2026

## PURPOSE
Complete Android mobile application for real call recording, forensic search, transcripts, and AI summaries. Full native Android integration. Records REAL incoming/outgoing calls, accesses real phone logs, stores audio files, and provides background monitoring.

## TECH STACK

### Android Native
- **Language**: Java
- **Min SDK**: 26 (Android 8.0), Target: 34 (Android 14)
- **Build Tool**: Gradle 8.x, AGP 8.x
- **Key Libraries**:
  - AndroidX (core, appcompat, lifecycle)
  - Material Design 3
  - WorkManager (background tasks)
  - Room (local database)
  - Retrofit + OkHttp (API calls)
  - MediaRecorder (native recording)

### Web (React)
- React 18/19, TypeScript, Vite, Tailwind CSS 4
- Zustand, Dexie.js, date-fns, framer-motion, lucide-react, uuid

### Bridge
- JavaScript Interface (WebViewClient) for Java↔JavaScript communication
- CallReceiver (BroadcastReceiver for call events)
- RecordingService (foreground service for background recording)

## FILE STRUCTURE
```
UltraCallVault/
├── android/
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml
│   │   │   ├── java/com/ultracall/vault/
│   │   │   │   ├── MainActivity.java
│   │   │   │   ├── App.java
│   │   │   │   ├── services/
│   │   │   │   │   ├── RecordingService.java
│   │   │   │   │   ├── CallReceiver.java
│   │   │   │   │   └── CallLogMonitor.java
│   │   │   │   ├── database/
│   │   │   │   │   ├── AppDatabase.java
│   │   │   │   │   ├── Recording.java
│   │   │   │   │   ├── RecordingDao.java
│   │   │   │   │   └── Converters.java
│   │   │   │   └── web/
│   │   │   │       └── JavaScriptInterface.java
│   │   │   ├── res/
│   │   │   │   ├── layout/activity_main.xml
│   │   │   │   └── values/
│   │   │   │       ├── strings.xml
│   │   │   │       └── colors.xml
│   │   │   └── assets/ (compiled React)
│   │   └── build.gradle
│   ├── gradle.properties
│   └── settings.gradle
├── web/
│   ├── src/
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   ├── index.css
│   │   ├── types/index.ts
│   │   ├── db/database.ts
│   │   ├── stores/
│   │   │   ├── appStore.ts
│   │   │   └── recordingsStore.ts
│   │   └── components/
│   │       ├── RecordingCard.tsx
│   │       ├── TabBar.tsx
│   │       ├── AudioPlayer.tsx
│   │       ├── PermissionCard.tsx
│   │       ├── RecordingsView.tsx
│   │       ├── SearchView.tsx
│   │       ├── TranscriptView.tsx
│   │       └── SettingsView.tsx
│   ├── index.html
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   ├── tsconfig.json
│   └── package.json
├── build-android.sh
├── package.json
└── SPEC.md
```

## FEATURES

### 1. Real Call Recording
- Triggered by CallReceiver on incoming/outgoing calls
- Uses MediaRecorder for audio capture
- Stores files in app-specific documents directory
- Foreground service with notification during recording

### 2. Background Service
- Foreground service keeps recording active
- Notification shown during recording
- Auto-starts on call events

### 3. Call Log Integration
- Reads system call logs via ContentResolver
- WorkManager for periodic monitoring
- Stores metadata in Room database

### 4. Permission Handling
- Double handshake (Android→WebView)
- Runtime permission requests
- Permission status updates to web UI

### 5. Forensic Search
- Full-text search across transcripts
- Filter by direction, date, duration
- Highlight matching terms

### 6. React UI
- Dark surveillance aesthetic
- Mobile-first responsive design
- Renders from compiled assets in WebView
- Sample data for demo mode

## UI DETAILS

### Colors
- Primary Background: #000111 (near-black)
- Secondary Background: #0a1628 (dark navy)
- Card Background: #111827 (slate-900)
- Primary Accent: #22d3ee (cyan-400)
- Secondary Accent: #8b5cf6 (violet-500)
- Recording Active: #ef4444 (red-500)
- Success: #22c55e (green-500)

### Typography
- Primary: Inter (Google Fonts)
- Monospace: JetBrains Mono
- Touch targets: 48px minimum

### Layout
- Bottom tab navigation (4 tabs)
- Safe area aware (notch/home indicator)
- Full-height cards with 12px rounded corners
- Pull-to-refresh on lists

## DATA MODELS

### Recording (Android)
```java
@Entity(tableName = "recordings")
public class Recording {
    @PrimaryKey(autoGenerate = true) public int id;
    public String callId;
    public String phoneNumber;
    public String contactName;
    public String direction;
    public Date startTime;
    public Date endTime;
    public int durationSeconds;
    public String audioFilePath;
    public String transcript;
    public String tags;
    public boolean isFavorite;
    public String sourceMethod;
    public String summary;
}
```

### Recording (TypeScript)
```typescript
interface Recording {
  id: string;
  callId: string;
  phoneNumber: string;
  contactName: string | null;
  direction: 'incoming' | 'outgoing' | 'unknown';
  startTime: Date;
  endTime: Date | null;
  durationSeconds: number;
  audioFilePath: string;
  transcript: string;
  summary: string;
  tags: string[];
  isFavorite: boolean;
  sourceMethod: 'system' | 'microphone' | 'both';
}
```

## BUILD PROCESS

### Phase 1: Setup & Install
```bash
cd web
npm install --legacy-peer-deps
```

### Phase 2: Build Web App
```bash
npm run build
# Output: web/dist/
```

### Phase 3: Sync to Android Assets
```bash
rm -rf android/app/src/main/assets/*
cp -r web/dist/* android/app/src/main/assets/
```

### Phase 4: Build APK
```bash
cd android
./gradlew clean build --parallel
./gradlew assembleRelease
```

### Or use build script:
```bash
chmod +x build-android.sh
./build-android.sh
```

## CONFIG/CONSTANTS

### Gradle Properties
- org.gradle.jvmargs=-Xmx2048m
- org.gradle.parallel=true
- org.gradle.caching=true
- android.useAndroidX=true
- android.enableJetifier=true

### Android SDK
- compileSdk: 34
- minSdk: 26
- targetSdk: 34

### Audio Recording
- Format: MPEG_4
- Encoder: AAC
- Bit Rate: 128000
- Sample Rate: 44100

## VALIDATION/EDGE CASES

1. **Permissions Denied**: Show graceful error message, disable recording features
2. **No Recordings**: Display empty state with instructions
3. **Recording Fails**: Catch exceptions, show toast notification
4. **Database Errors**: Log errors, fallback to sample data
5. **WebView Not Available**: Android bridge checks for fallback mode

## DEPENDENCIES (Web)
- react: ^18.3.1
- react-dom: ^18.3.1
- zustand: ^4.5.2
- dexie: ^4.0.4
- date-fns: ^3.6.0
- framer-motion: ^11.2.10
- lucide-react: ^0.378.0
- uuid: ^9.0.1

## DEPENDENCIES (Android)
- androidx.appcompat:appcompat:1.6.1
- androidx.core:core:1.12.0
- androidx.lifecycle:lifecycle-runtime-ktx:2.7.0
- androidx.room:room-runtime:2.6.1
- androidx.work:work-runtime:2.9.0
- com.google.android.material:material:1.11.0
- com.google.code.gson:gson:2.10.1

## CRITICAL NOTES
- ⚠️ Real device required for call recording (emulator won't trigger CallReceiver)
- ⚠️ Foreground service notification required on Android 8+
- ⚠️ Permissions must be granted via system dialog before recording
- ⚠️ Build in phases to prevent token exhaustion
- ⚠️ Monitor Gradle memory with -Xmx2048m
