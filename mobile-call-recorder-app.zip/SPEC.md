# SPEC.md — UltraCall Vault 2026

## 1. Concept & Vision

**UltraCall Vault** is a forensic-grade call recording application with AI-powered transcription and summarization. It feels like a professional surveillance tool meets modern mobile design—dark, tactical, yet intuitive. The app exudes trust through systematic organization and provides powerful search capabilities for legal or business use.

## 2. Design Language

### Aesthetic Direction
Military-grade surveillance aesthetic with neon accents. Think cyberpunk control room meets professional evidence locker.

### Color Palette
- **Primary Background**: `#000111` (near-black with blue tint)
- **Secondary Background**: `#0a1628` (dark navy)
- **Card Background**: `#111827` (slate-900)
- **Primary Accent**: `#22d3ee` (cyan-400)
- **Secondary Accent**: `#8b5cf6` (violet-500)
- **Recording Active**: `#ef4444` (red-500)
- **Success**: `#22c55e` (green-500)
- **Text Primary**: `#f8fafc` (slate-50)
- **Text Secondary**: `#94a3b8` (slate-400)

### Typography
- **Primary Font**: Inter (Google Fonts)
- **Monospace**: JetBrains Mono (for timestamps, IDs)
- **Fallbacks**: system-ui, sans-serif

### Spatial System
- Base unit: 4px
- Card padding: 16px
- Section gaps: 24px
- Touch targets: minimum 48px

### Motion Philosophy
- Subtle slide-up for modals (200ms ease-out)
- Pulse animation for recording indicator
- Fade transitions between views (150ms)

## 3. Layout & Structure

### Navigation
Bottom tab bar with 4 main sections:
1. **Recordings** - List of all call recordings
2. **Search** - Forensic search interface
3. **Transcript** - AI transcription view
4. **Settings** - Configuration and permissions

### Screen Structure
- Safe area aware (notch, home indicator)
- Full-height cards with rounded corners (12px)
- Sticky headers with blur backdrop
- Pull-to-refresh on lists

## 4. Features & Interactions

### Core Features
1. **Recording List**
   - Sorted by date (newest first)
   - Shows: contact name, phone, duration, direction indicator
   - Swipe left to delete, tap to play
   - Long-press for bulk selection

2. **Real-Time Recording**
   - Visual indicator when recording active
   - Auto-start on calls (configurable)
   - Manual recording button

3. **Forensic Search**
   - Full-text search across transcripts
   - Filter by date range, direction, duration
   - Highlight matching terms

4. **Transcript View**
   - Playback synchronized with text
   - Copy/export functionality
   - AI summary generation

5. **Settings**
   - Permission status indicators
   - Auto-record toggle
   - Storage management
   - Export options

### States
- **Empty**: "No recordings yet" with mic icon
- **Loading**: Skeleton cards with pulse
- **Error**: Red banner with retry button
- **Recording**: Pulsing red dot indicator

## 5. Component Inventory

### RecordingCard
- Contact avatar (initials or icon)
- Phone number (masked option)
- Duration badge
- Direction icon (incoming/outgoing)
- Favorite star toggle
- States: default, playing, selected

### AudioPlayer
- Play/pause button
- Progress bar (draggable)
- Time display (current/total)
- Playback speed selector

### SearchBar
- Debounced input (300ms)
- Clear button
- Filter dropdown

### PermissionCard
- Permission name
- Status icon (granted/denied)
- "Request" button if missing

### TabBar
- 4 icons with labels
- Active state indicator
- Badge for new recordings

## 6. Technical Approach

### Web Stack (React)
- React 18 with TypeScript
- Vite build tool
- Tailwind CSS 4
- Zustand for state
- Dexie.js for IndexedDB
- date-fns for formatting

### Data Model
```typescript
interface Recording {
  id: string;
  callId: string;
  phoneNumber: string;
  contactName: string | null;
  direction: 'incoming' | 'outgoing' | 'unknown';
  startTime: Date;
  endTime: Date | null;
  durationSeconds: number;
  audioFilePath: string;
  transcript: string;
  summary: string;
  tags: string[];
  isFavorite: boolean;
  sourceMethod: 'system' | 'microphone' | 'both';
}
```

### Storage
- IndexedDB via Dexie.js for web
- Room Database for Android native
- Audio files in app-specific storage

### Android Integration
- WebView with JavaScript interface
- BroadcastReceiver for call events
- Foreground Service for recording
- Room for local persistence
