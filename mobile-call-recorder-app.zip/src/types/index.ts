// Core data types for UltraCall Vault

export interface Recording {
  id: string;
  callId: string;
  phoneNumber: string;
  contactName: string | null;
  direction: 'incoming' | 'outgoing' | 'unknown';
  startTime: Date;
  endTime: Date | null;
  durationSeconds: number;
  audioFilePath: string;
  transcript: string;
  summary: string;
  tags: string[];
  isFavorite: boolean;
  sourceMethod: 'system' | 'microphone' | 'both';
}

export interface SearchFilters {
  keyword: string;
  dateFrom: Date | null;
  dateTo: Date | null;
  direction: ('incoming' | 'outgoing')[];
  durationMin: number;
  durationMax: number;
  favoritesOnly: boolean;
}

export interface Permission {
  name: string;
  key: string;
  granted: boolean;
  required: boolean;
}

export interface AppSettings {
  autoRecord: boolean;
  recordIncoming: boolean;
  recordOutgoing: boolean;
  audioQuality: 'low' | 'medium' | 'high';
  storageLimit: number; // MB
  darkMode: boolean;
}

// Android bridge types
export interface AndroidBridge {
  getAllRecordings(): string;
  deleteRecording(id: number): void;
  toggleFavorite(id: number): void;
  startRecording(): void;
  stopRecording(): void;
  getPermissionStatus(): string;
  requestPermission(perm: string): void;
}

declare global {
  interface Window {
    Android?: AndroidBridge;
  }
}
