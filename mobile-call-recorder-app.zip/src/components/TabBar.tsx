import { Mic, MicOff, Settings, User, LogOut } from 'lucide-react';
import { useAppStore } from '../stores/appStore';
import { useRecordingsStore } from '../stores/recordingsStore';

export function TabBar() {
  const { currentView, setView, isRecording, setRecording } = useAppStore();
  const { setSelectedRecording } = useRecordingsStore();

  const tabs = [
    { id: 'recordings' as const, label: 'Recordings', icon: Mic },
    { id: 'search' as const, label: 'Search', icon: MicOff },
    { id: 'transcript' as const, label: 'Transcript', icon: User },
    { id: 'settings' as const, label: 'Settings', icon: Settings },
  ];

  const handleTabPress = (tabId: typeof tabs[number]['id']) => {
    setView(tabId);
    if (tabId !== 'transcript') {
      setSelectedRecording(null);
    }
  };

  const toggleRecording = () => {
    if (isRecording) {
      window.Android?.stopRecording();
    } else {
      window.Android?.startRecording();
    }
    setRecording(!isRecording);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-vault-bg-secondary/95 backdrop-blur-lg border-t border-slate-800 safe-bottom z-50">
      <div className="flex items-center justify-around px-2 py-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentView === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => handleTabPress(tab.id)}
              className={`flex flex-col items-center justify-center p-2 min-w-[64px] touch-target ${
                isActive ? 'tab-active' : 'tab-inactive'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-vault-cyan' : ''}`} />
              <span className="text-xs mt-1">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
