import { useEffect } from 'react';
import { RefreshCw, Mic } from 'lucide-react';
import { useRecordingsStore } from '../stores/recordingsStore';
import { RecordingCard } from './RecordingCard';
import { AudioPlayer } from './AudioPlayer';
import type { Recording } from '../types';

export function RecordingsView() {
  const {
    recordings,
    loading,
    selectedRecording,
    playingId,
    loadRecordings,
    setSelectedRecording,
    setPlayingId,
    toggleFavorite,
  } = useRecordingsStore();

  useEffect(() => {
    loadRecordings();
  }, [loadRecordings]);

  const handlePlay = (id: string) => {
    if (playingId === id) {
      setPlayingId(null);
    } else {
      setPlayingId(id);
    }
  };

  if (loading && recordings.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 text-vault-cyan animate-spin" />
      </div>
    );
  }

  if (recordings.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mb-4">
          <Mic className="w-8 h-8 text-slate-500" />
        </div>
        <h3 className="text-lg font-medium text-slate-300 mb-2">No recordings yet</h3>
        <p className="text-sm text-slate-500 max-w-xs">
          Your call recordings will appear here. Make sure to grant permissions in Settings.
        </p>
      </div>
    );
  }

  return (
    <div className="pb-4">
      {recordings.map((recording: Recording) => (
        <RecordingCard
          key={recording.id}
          recording={recording}
          isPlaying={playingId === recording.id}
          onPlay={() => handlePlay(recording.id)}
          onSelect={() => setSelectedRecording(recording)}
          onToggleFavorite={() => toggleFavorite(recording.id)}
        />
      ))}

      {selectedRecording && playingId && (
        <AudioPlayer
          recording={selectedRecording}
          isPlaying={playingId === selectedRecording.id}
          onPlayPause={() => setPlayingId(playingId === selectedRecording.id ? null : selectedRecording.id)}
          onClose={() => {
            setPlayingId(null);
            setSelectedRecording(null);
          }}
        />
      )}
    </div>
  );
}
