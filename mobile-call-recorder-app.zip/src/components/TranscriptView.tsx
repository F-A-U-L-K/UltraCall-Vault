import { ArrowLeft, Copy, Share2, Star } from 'lucide-react';
import { useRecordingsStore } from '../stores/recordingsStore';
import { useAppStore } from '../stores/appStore';
import { format } from 'date-fns';

export function TranscriptView() {
  const { selectedRecording, toggleFavorite } = useRecordingsStore();
  const { setView, setRecording } = useAppStore();

  if (!selectedRecording) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mb-4">
          <Star className="w-8 h-8 text-slate-500" />
        </div>
        <h3 className="text-lg font-medium text-slate-300 mb-2">
          No recording selected
        </h3>
        <p className="text-sm text-slate-500 max-w-xs">
          Select a recording from the list to view its transcript and details.
        </p>
      </div>
    );
  }

  const handleBack = () => {
    setView('recordings');
    setRecording(false);
  };

  const copyTranscript = () => {
    navigator.clipboard.writeText(selectedRecording.transcript);
  };

  const shareTranscript = async () => {
    const text = `Call Recording\nFrom: ${selectedRecording.contactName || 'Unknown'}\nNumber: ${selectedRecording.phoneNumber}\nDate: ${format(selectedRecording.startTime, 'PPpp')}\n\nTranscript:\n${selectedRecording.transcript}`;
    
    if (navigator.share) {
      await navigator.share({ text });
    } else {
      navigator.clipboard.writeText(text);
    }
  };

  return (
    <div className="pb-20">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={handleBack}
          className="p-2 rounded-lg bg-slate-800 touch-target"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <h2 className="font-semibold text-lg">
            {selectedRecording.contactName || 'Unknown Contact'}
          </h2>
          <p className="text-sm text-slate-400 font-mono">
            {selectedRecording.phoneNumber}
          </p>
        </div>
        <button
          onClick={() => toggleFavorite(selectedRecording.id)}
          className="p-2 rounded-lg bg-slate-800"
        >
          <Star
            className={`w-5 h-5 ${
              selectedRecording.isFavorite
                ? 'fill-vault-cyan text-vault-cyan'
                : 'text-slate-400'
            }`}
          />
        </button>
      </div>

      {/* Call Info */}
      <div className="card mb-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-slate-500 mb-1">Direction</p>
            <span
              className={`badge ${
                selectedRecording.direction === 'incoming'
                  ? 'badge-incoming'
                  : 'badge-outgoing'
              }`}
            >
              {selectedRecording.direction}
            </span>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Duration</p>
            <p className="font-mono text-slate-200">
              {Math.floor(selectedRecording.durationSeconds / 60)}:
              {(selectedRecording.durationSeconds % 60)
                .toString()
                .padStart(2, '0')}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Date</p>
            <p className="text-sm text-slate-200">
              {format(selectedRecording.startTime, 'MMM d, yyyy')}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Time</p>
            <p className="text-sm text-slate-200">
              {format(selectedRecording.startTime, 'h:mm a')}
            </p>
          </div>
        </div>
      </div>

      {/* AI Summary */}
      {selectedRecording.summary && (
        <div className="card mb-4 border-vault-cyan/30">
          <p className="text-xs text-vault-cyan mb-2 font-medium">AI SUMMARY</p>
          <p className="text-slate-200">{selectedRecording.summary}</p>
        </div>
      )}

      {/* Transcript */}
      <div className="card mb-4">
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm text-slate-400 font-medium">TRANSCRIPT</p>
          <div className="flex gap-2">
            <button
              onClick={copyTranscript}
              className="p-2 text-slate-400 hover:text-slate-200"
              title="Copy"
            >
              <Copy className="w-4 h-4" />
            </button>
            <button
              onClick={shareTranscript}
              className="p-2 text-slate-400 hover:text-slate-200"
              title="Share"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>
        <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">
          {selectedRecording.transcript}
        </p>
      </div>

      {/* Tags */}
      {selectedRecording.tags.length > 0 && (
        <div className="card">
          <p className="text-sm text-slate-400 font-medium mb-3">TAGS</p>
          <div className="flex flex-wrap gap-2">
            {selectedRecording.tags.map((tag: string) => (
              <span
                key={tag}
                className="badge bg-slate-700 text-slate-300 px-3 py-1"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
