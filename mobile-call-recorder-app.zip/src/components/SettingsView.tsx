import { useAppStore } from '../stores/appStore';
import { PermissionCard } from './PermissionCard';
import type { Permission } from '../types';

export function SettingsView() {
  const { permissions, settings, updateSettings } = useAppStore();

  const requestPermission = (key: string) => {
    window.Android?.requestPermission(key);
  };

  return (
    <div className="pb-20">
      {/* Permissions Section */}
      <h3 className="text-sm font-medium text-slate-500 mb-3 uppercase tracking-wider">
        Permissions
      </h3>
        {permissions.map((permission: Permission) => (
        <PermissionCard
          key={permission.key}
          permission={permission}
          onRequest={() => requestPermission(permission.key)}
        />
      ))}

      {/* Recording Settings */}
      <h3 className="text-sm font-medium text-slate-500 mb-3 mt-6 uppercase tracking-wider">
        Recording Settings
      </h3>
      <div className="card mb-4 space-y-4">
        <label className="flex items-center justify-between cursor-pointer">
          <div>
            <p className="font-medium text-slate-200">Auto-Record</p>
            <p className="text-xs text-slate-500">
              Automatically record all calls
            </p>
          </div>
          <input
            type="checkbox"
            checked={settings.autoRecord}
            onChange={(e) => updateSettings({ autoRecord: e.target.checked })}
            className="w-5 h-5 rounded bg-slate-700 border-slate-600 text-vault-cyan focus:ring-vault-cyan"
          />
        </label>

        <div className="border-t border-slate-700 pt-4">
          <label className="flex items-center justify-between cursor-pointer">
            <div>
              <p className="font-medium text-slate-200">Record Incoming</p>
              <p className="text-xs text-slate-500">
                Record incoming calls automatically
              </p>
            </div>
            <input
              type="checkbox"
              checked={settings.recordIncoming}
              onChange={(e) =>
                updateSettings({ recordIncoming: e.target.checked })
              }
              className="w-5 h-5 rounded bg-slate-700 border-slate-600 text-vault-cyan focus:ring-vault-cyan"
            />
          </label>
        </div>

        <div className="border-t border-slate-700 pt-4">
          <label className="flex items-center justify-between cursor-pointer">
            <div>
              <p className="font-medium text-slate-200">Record Outgoing</p>
              <p className="text-xs text-slate-500">
                Record outgoing calls automatically
              </p>
            </div>
            <input
              type="checkbox"
              checked={settings.recordOutgoing}
              onChange={(e) =>
                updateSettings({ recordOutgoing: e.target.checked })
              }
              className="w-5 h-5 rounded bg-slate-700 border-slate-600 text-vault-cyan focus:ring-vault-cyan"
            />
          </label>
        </div>
      </div>

      {/* Audio Quality */}
      <h3 className="text-sm font-medium text-slate-500 mb-3 mt-6 uppercase tracking-wider">
        Audio Quality
      </h3>
      <div className="card mb-4">
        <div className="flex gap-2">
          {(['low', 'medium', 'high'] as const).map((quality) => (
            <button
              key={quality}
              onClick={() => updateSettings({ audioQuality: quality })}
              className={`flex-1 py-3 rounded-lg text-sm font-medium transition-colors ${
                settings.audioQuality === quality
                  ? 'bg-vault-cyan text-vault-bg'
                  : 'bg-slate-700 text-slate-300'
              }`}
            >
              {quality.charAt(0).toUpperCase() + quality.slice(1)}
            </button>
          ))}
        </div>
        <p className="text-xs text-slate-500 mt-2">
          {settings.audioQuality === 'low' && '64 kbps - Saves storage'}
          {settings.audioQuality === 'medium' && '96 kbps - Balanced'}
          {settings.audioQuality === 'high' && '128 kbps - Best quality'}
        </p>
      </div>

      {/* Storage Info */}
      <h3 className="text-sm font-medium text-slate-500 mb-3 mt-6 uppercase tracking-wider">
        Storage
      </h3>
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <span className="text-slate-400">Used Space</span>
          <span className="font-mono text-slate-200">124.5 MB</span>
        </div>
        <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
          <div
            className="h-full bg-vault-cyan rounded-full"
            style={{ width: '2.5%' }}
          />
        </div>
        <p className="text-xs text-slate-500 mt-2">
          of {settings.storageLimit} MB limit
        </p>
      </div>

      {/* App Info */}
      <div className="mt-8 text-center text-xs text-slate-600">
        <p>UltraCall Vault v1.0.0</p>
        <p className="mt-1">Forensic-grade call recording</p>
      </div>
    </div>
  );
}
