import { useEffect, useRef, useState } from 'react';
import { Play, Pause, SkipBack, SkipForward } from 'lucide-react';
import type { Recording } from '../types';

interface AudioPlayerProps {
  recording: Recording;
  isPlaying: boolean;
  onPlayPause: () => void;
  onClose: () => void;
}

export function AudioPlayer({
  recording,
  isPlaying,
  onPlayPause,
  onClose,
}: AudioPlayerProps) {
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const intervalRef = useRef<number | null>(null);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = window.setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= recording.durationSeconds) {
            onPlayPause();
            return 0;
          }
          return prev + 1;
        });
        setProgress((currentTime / recording.durationSeconds) * 100);
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isPlaying, recording.durationSeconds, onPlayPause]);

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    const newTime = percentage * recording.durationSeconds;
    setCurrentTime(newTime);
    setProgress(percentage * 100);
  };

  const skipBack = () => {
    setCurrentTime((prev) => Math.max(0, prev - 10));
  };

  const skipForward = () => {
    setCurrentTime((prev) =>
      Math.min(recording.durationSeconds, prev + 10)
    );
  };

  return (
    <div className="fixed bottom-16 left-0 right-0 bg-vault-card border-t border-slate-700 p-4 safe-bottom animate-slide-up">
      <div className="flex items-center gap-3">
        <button
          onClick={skipBack}
          className="p-2 text-slate-400 hover:text-slate-200"
        >
          <SkipBack className="w-5 h-5" />
        </button>

        <button
          onClick={onPlayPause}
          className="w-12 h-12 rounded-full bg-vault-cyan text-vault-bg flex items-center justify-center"
        >
          {isPlaying ? (
            <Pause className="w-5 h-5" />
          ) : (
            <Play className="w-5 h-5 ml-0.5" />
          )}
        </button>

        <button
          onClick={skipForward}
          className="p-2 text-slate-400 hover:text-slate-200"
        >
          <SkipForward className="w-5 h-5" />
        </button>

        <div className="flex-1">
          <div
            className="h-1 bg-slate-700 rounded-full cursor-pointer"
            onClick={handleSeek}
          >
            <div
              className="h-full bg-vault-cyan rounded-full transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between mt-1 text-xs font-mono text-slate-500">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(recording.durationSeconds)}</span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-2 text-slate-400 hover:text-slate-200"
        >
          <span className="sr-only">Close</span>
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>
  );
}
