import { Phone, PhoneOutgoing, Star } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import type { Recording } from '../types';

interface RecordingCardProps {
  recording: Recording;
  isPlaying: boolean;
  onPlay: () => void;
  onSelect: () => void;
  onToggleFavorite: () => void;
}

export function RecordingCard({
  recording,
  isPlaying,
  onPlay,
  onSelect,
  onToggleFavorite,
}: RecordingCardProps) {
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getInitials = (name: string | null, phone: string) => {
    if (name) {
      return name
        .split(' ')
        .map((n) => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2);
    }
    return phone.slice(-4);
  };

  return (
    <div
      className="card mb-3 active:scale-[0.98] transition-transform cursor-pointer"
      onClick={onSelect}
    >
      <div className="flex items-start gap-3">
        {/* Avatar */}
        <div
          className={`w-12 h-12 rounded-full flex items-center justify-center font-mono text-sm ${
            recording.direction === 'incoming'
              ? 'bg-vault-cyan/20 text-vault-cyan'
              : 'bg-vault-violet/20 text-vault-violet'
          }`}
        >
          {getInitials(recording.contactName, recording.phoneNumber)}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <span className="font-medium text-slate-100 truncate">
              {recording.contactName || 'Unknown'}
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleFavorite();
              }}
              className="p-2 touch-target"
            >
              <Star
                className={`w-4 h-4 ${
                  recording.isFavorite
                    ? 'fill-vault-cyan text-vault-cyan'
                    : 'text-slate-500'
                }`}
              />
            </button>
          </div>

          <p className="text-sm text-slate-400 font-mono">{recording.phoneNumber}</p>

          <div className="flex items-center gap-2 mt-2">
            <span
              className={`badge ${
                recording.direction === 'incoming'
                  ? 'badge-incoming'
                  : 'badge-outgoing'
              }`}
            >
              {recording.direction === 'incoming' ? (
                <Phone className="w-3 h-3 mr-1" />
              ) : (
                <PhoneOutgoing className="w-3 h-3 mr-1" />
              )}
              {recording.direction}
            </span>
            <span className="text-xs text-slate-500 font-mono">
              {formatDistanceToNow(recording.startTime, { addSuffix: true })}
            </span>
          </div>
        </div>

        {/* Duration & Play */}
        <div className="flex flex-col items-center gap-2">
          <span className="text-sm font-mono text-slate-300">
            {formatDuration(recording.durationSeconds)}
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onPlay();
            }}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
              isPlaying
                ? 'bg-vault-cyan text-vault-bg'
                : 'bg-slate-700 text-slate-200'
            }`}
          >
            {isPlaying ? (
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <rect x="6" y="4" width="4" height="16" />
                <rect x="14" y="4" width="4" height="16" />
              </svg>
            ) : (
              <svg className="w-4 h-4 ml-0.5" fill="currentColor" viewBox="0 0 24 24">
                <polygon points="5,3 19,12 5,21" />
              </svg>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
