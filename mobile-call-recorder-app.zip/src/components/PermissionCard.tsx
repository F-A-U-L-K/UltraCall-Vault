import { ShieldOff, Check } from 'lucide-react';
import type { Permission } from '../types';

interface PermissionCardProps {
  permission: Permission;
  onRequest: () => void;
}

export function PermissionCard({ permission, onRequest }: PermissionCardProps) {
  return (
    <div className="card mb-3 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div
          className={`w-10 h-10 rounded-full flex items-center justify-center ${
            permission.granted
              ? 'bg-vault-green/20 text-vault-green'
              : 'bg-slate-700 text-slate-400'
          }`}
        >
          {permission.granted ? (
            <Check className="w-5 h-5" />
          ) : (
            <ShieldOff className="w-5 h-5" />
          )}
        </div>
        <div>
          <p className="font-medium text-slate-100">{permission.name}</p>
          <p className="text-xs text-slate-500">
            {permission.required ? 'Required' : 'Optional'}
          </p>
        </div>
      </div>

      {permission.granted ? (
        <span className="badge bg-vault-green/20 text-vault-green">Granted</span>
      ) : (
        <button onClick={onRequest} className="btn-secondary text-sm py-2">
          Request
        </button>
      )}
    </div>
  );
}
