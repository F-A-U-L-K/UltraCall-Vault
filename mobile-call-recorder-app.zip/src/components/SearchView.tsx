import { useEffect, useState } from 'react';
import { Search, Filter, X } from 'lucide-react';
import { useRecordingsStore } from '../stores/recordingsStore';
import { useAppStore } from '../stores/appStore';
import type { Recording } from '../types';

export function SearchView() {
  const { filters, updateFilters, searchRecordings, searchResults, setSelectedRecording } =
    useRecordingsStore();
  const { setView, setRecording } = useAppStore();
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    searchRecordings();
  }, [filters, searchRecordings]);

  const handleKeywordChange = (keyword: string) => {
    updateFilters({ keyword });
  };

  const handleDirectionToggle = (direction: 'incoming' | 'outgoing') => {
    const current = filters.direction;
    const updated = current.includes(direction)
      ? current.filter((d: string) => d !== direction)
      : [...current, direction];
    updateFilters({ direction: updated as ('incoming' | 'outgoing')[] });
  };

  const handleResultClick = (recording: Recording) => {
    setSelectedRecording(recording);
    setView('transcript');
    setRecording(false);
  };

  return (
    <div>
      {/* Search Input */}
      <div className="relative mb-4">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
        <input
          type="text"
          placeholder="Search transcripts, contacts, numbers..."
          value={filters.keyword}
          onChange={(e) => handleKeywordChange(e.target.value)}
          className="input-field w-full pl-12 pr-10"
        />
        {filters.keyword && (
          <button
            onClick={() => updateFilters({ keyword: '' })}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-1"
          >
            <X className="w-4 h-4 text-slate-500" />
          </button>
        )}
      </div>

      {/* Filter Toggle */}
      <button
        onClick={() => setShowFilters(!showFilters)}
        className="btn-secondary w-full mb-4 flex items-center justify-center gap-2"
      >
        <Filter className="w-4 h-4" />
        Filters
        {filters.direction.length > 0 && (
          <span className="badge badge-incoming ml-2">
            {filters.direction.length}
          </span>
        )}
      </button>

      {/* Filter Panel */}
      {showFilters && (
        <div className="card mb-4 animate-fade-in">
          <p className="text-sm text-slate-400 mb-3">Direction</p>
          <div className="flex gap-2 mb-4">
            <button
              onClick={() => handleDirectionToggle('incoming')}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
                filters.direction.includes('incoming')
                  ? 'bg-vault-cyan text-vault-bg'
                  : 'bg-slate-700 text-slate-300'
              }`}
            >
              Incoming
            </button>
            <button
              onClick={() => handleDirectionToggle('outgoing')}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
                filters.direction.includes('outgoing')
                  ? 'bg-vault-violet text-white'
                  : 'bg-slate-700 text-slate-300'
              }`}
            >
              Outgoing
            </button>
          </div>

          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={filters.favoritesOnly}
              onChange={(e) => updateFilters({ favoritesOnly: e.target.checked })}
              className="w-5 h-5 rounded bg-slate-700 border-slate-600 text-vault-cyan focus:ring-vault-cyan"
            />
            <span className="text-sm text-slate-300">Favorites only</span>
          </label>
        </div>
      )}

      {/* Results */}
      <div className="space-y-3">
        <p className="text-sm text-slate-500 mb-2">
          {searchResults.length} result{searchResults.length !== 1 ? 's' : ''}
        </p>

        {searchResults.map((recording: Recording) => (
          <div
            key={recording.id}
            onClick={() => handleResultClick(recording)}
            className="card cursor-pointer hover:border-slate-600 transition-colors"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium text-slate-200">
                {recording.contactName || 'Unknown'}
              </span>
              <span
                className={`badge ${
                  recording.direction === 'incoming'
                    ? 'badge-incoming'
                    : 'badge-outgoing'
                }`}
              >
                {recording.direction}
              </span>
            </div>
            <p className="text-sm text-slate-400 font-mono mb-2">
              {recording.phoneNumber}
            </p>
            <p className="text-sm text-slate-500 line-clamp-2">
              {recording.transcript}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
