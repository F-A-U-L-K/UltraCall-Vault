import { useEffect } from 'react';
import { useAppStore } from './stores/appStore';
import { useRecordingsStore } from './stores/recordingsStore';
import { TabBar } from './components/TabBar';
import { RecordingsView } from './components/RecordingsView';
import { SearchView } from './components/SearchView';
import { TranscriptView } from './components/TranscriptView';
import { SettingsView } from './components/SettingsView';
import { Mic, Shield } from 'lucide-react';

function App() {
  const { currentView, isRecording, setRecording } = useAppStore();
  const { loadRecordings } = useRecordingsStore();

  useEffect(() => {
    loadRecordings();

    // Listen for permission updates from Android
    if (typeof window !== 'undefined') {
      (window as any).onPermissionUpdate = (granted: boolean) => {
        console.log('Permission update:', granted);
      };
    }
  }, [loadRecordings]);

  const renderView = () => {
    switch (currentView) {
      case 'recordings':
        return <RecordingsView />;
      case 'search':
        return <SearchView />;
      case 'transcript':
        return <TranscriptView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <RecordingsView />;
    }
  };

  return (
    <div className="min-h-screen min-h-[100dvh] flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-vault-bg/95 backdrop-blur-lg border-b border-slate-800 safe-top">
        <div className="px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-vault-cyan to-vault-violet flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-semibold text-lg">UltraCall Vault</h1>
              <p className="text-xs text-slate-500">Forensic Recording</p>
            </div>
          </div>

          {/* Recording Indicator */}
          <div className="flex items-center gap-2">
            {isRecording && (
              <div className="flex items-center gap-2 bg-vault-red/20 px-3 py-1.5 rounded-full animate-pulse-recording">
                <div className="w-2 h-2 rounded-full bg-vault-red" />
                <span className="text-xs font-medium text-vault-red">REC</span>
              </div>
            )}
            <button className="p-2 rounded-lg bg-slate-800">
              <Mic className={`w-5 h-5 ${isRecording ? 'text-vault-red' : 'text-slate-400'}`} />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 py-4 pb-20 overflow-y-auto">
        {renderView()}
      </main>

      {/* Tab Bar */}
      <TabBar />
    </div>
  );
}

export default App;
