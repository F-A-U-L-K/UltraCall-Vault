import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { AppSettings, Permission } from '../types';

interface AppState {
  isRecording: boolean;
  currentView: 'recordings' | 'search' | 'transcript' | 'settings';
  permissions: Permission[];
  settings: AppSettings;
  setRecording: (recording: boolean) => void;
  setView: (view: AppState['currentView']) => void;
  updatePermission: (key: string, granted: boolean) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
}

const defaultPermissions: Permission[] = [
  { name: 'Microphone', key: 'RECORD_AUDIO', granted: false, required: true },
  { name: 'Phone State', key: 'READ_PHONE_STATE', granted: false, required: true },
  { name: 'Call Logs', key: 'READ_CALL_LOG', granted: false, required: true },
  { name: 'Storage', key: 'STORAGE', granted: false, required: false },
];

const defaultSettings: AppSettings = {
  autoRecord: true,
  recordIncoming: true,
  recordOutgoing: true,
  audioQuality: 'high',
  storageLimit: 5000,
  darkMode: true,
};

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      isRecording: false,
      currentView: 'recordings',
      permissions: defaultPermissions,
      settings: defaultSettings,

      setRecording: (recording) => set({ isRecording: recording }),
      
      setView: (view) => set({ currentView: view }),
      
      updatePermission: (key, granted) =>
        set((state) => ({
          permissions: state.permissions.map((p) =>
            p.key === key ? { ...p, granted } : p
          ),
        })),
      
      updateSettings: (newSettings) =>
        set((state) => ({
          settings: { ...state.settings, ...newSettings },
        })),
    }),
    {
      name: 'ultracall-settings',
    }
  )
);
