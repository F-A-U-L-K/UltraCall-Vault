import { create } from 'zustand';
import { Recording, SearchFilters } from '../types';
import { db, sampleRecordings } from '../db/database';
import { v4 as uuidv4 } from 'uuid';

interface RecordingsState {
  recordings: Recording[];
  selectedRecording: Recording | null;
  playingId: string | null;
  loading: boolean;
  searchResults: Recording[];
  filters: SearchFilters;
  
  loadRecordings: () => Promise<void>;
  addRecording: (recording: Omit<Recording, 'id'>) => Promise<void>;
  deleteRecording: (id: string) => Promise<void>;
  toggleFavorite: (id: string) => Promise<void>;
  setSelectedRecording: (rec: Recording | null) => void;
  setPlayingId: (id: string | null) => void;
  updateFilters: (filters: Partial<SearchFilters>) => void;
  searchRecordings: () => void;
}

const defaultFilters: SearchFilters = {
  keyword: '',
  dateFrom: null,
  dateTo: null,
  direction: [],
  durationMin: 0,
  durationMax: 3600,
  favoritesOnly: false,
};

export const useRecordingsStore = create<RecordingsState>((set, get) => ({
  recordings: [],
  selectedRecording: null,
  playingId: null,
  loading: false,
  searchResults: [],
  filters: defaultFilters,

  loadRecordings: async () => {
    set({ loading: true });
    try {
      // Try Android bridge first
      if (window.Android?.getAllRecordings) {
        const jsonStr = window.Android.getAllRecordings();
        const recs = JSON.parse(jsonStr) as Recording[];
        set({ recordings: recs, loading: false });
        return;
      }
      
      // Fallback to IndexedDB
      const recs = await db.recordings.toArray();
      if (recs.length === 0) {
        // Load sample data for demo
        await db.recordings.bulkAdd(sampleRecordings);
        set({ recordings: sampleRecordings, loading: false });
      } else {
        set({ recordings: recs, loading: false });
      }
    } catch (e) {
      console.error('Failed to load recordings:', e);
      set({ recordings: sampleRecordings, loading: false });
    }
  },

  addRecording: async (recording) => {
    const newRecording = { ...recording, id: uuidv4() };
    await db.recordings.add(newRecording);
    set((state) => ({
      recordings: [newRecording, ...state.recordings],
    }));
  },

  deleteRecording: async (id) => {
    if (window.Android?.deleteRecording) {
      window.Android.deleteRecording(parseInt(id));
    }
    await db.recordings.delete(id);
    set((state) => ({
      recordings: state.recordings.filter((r) => r.id !== id),
      selectedRecording:
        state.selectedRecording?.id === id ? null : state.selectedRecording,
    }));
  },

  toggleFavorite: async (id) => {
    const recording = await db.recordings.get(id);
    if (recording) {
      const updated = { ...recording, isFavorite: !recording.isFavorite };
      await db.recordings.put(updated);
      if (window.Android?.toggleFavorite) {
        window.Android.toggleFavorite(parseInt(id));
      }
      set((state) => ({
        recordings: state.recordings.map((r) =>
          r.id === id ? updated : r
        ),
        selectedRecording:
          state.selectedRecording?.id === id ? updated : state.selectedRecording,
      }));
    }
  },

  setSelectedRecording: (rec) => set({ selectedRecording: rec }),
  setPlayingId: (id) => set({ playingId: id }),

  updateFilters: (newFilters) =>
    set((state) => ({
      filters: { ...state.filters, ...newFilters },
    })),

  searchRecordings: () => {
    const { recordings, filters } = get();
    let results = [...recordings];

    if (filters.keyword) {
      const kw = filters.keyword.toLowerCase();
      results = results.filter(
        (r) =>
          r.transcript.toLowerCase().includes(kw) ||
          r.contactName?.toLowerCase().includes(kw) ||
          r.phoneNumber.includes(filters.keyword)
      );
    }

    if (filters.direction.length > 0) {
      results = results.filter((r) => filters.direction.includes(r.direction));
    }

    if (filters.favoritesOnly) {
      results = results.filter((r) => r.isFavorite);
    }

    if (filters.dateFrom) {
      results = results.filter((r) => r.startTime >= filters.dateFrom!);
    }

    if (filters.dateTo) {
      results = results.filter((r) => r.startTime <= filters.dateTo!);
    }

    results = results.filter(
      (r) =>
        r.durationSeconds >= filters.durationMin &&
        r.durationSeconds <= filters.durationMax
    );

    set({ searchResults: results });
  },
}));
