import Dexie, { Table } from 'dexie';
import { Recording } from '../types';

export class UltraCallDB extends Dexie {
  recordings!: Table<Recording, string>;

  constructor() {
    super('UltraCallVault');
    this.version(1).stores({
      recordings: 'id, callId, phoneNumber, contactName, direction, startTime, isFavorite',
    });
  }
}

export const db = new UltraCallDB();

// Sample data for demo
export const sampleRecordings: Recording[] = [
  {
    id: '1',
    callId: 'call-001',
    phoneNumber: '+1 (555) 123-4567',
    contactName: 'Sarah Mitchell',
    direction: 'incoming',
    startTime: new Date(Date.now() - 3600000),
    endTime: new Date(Date.now() - 3000000),
    durationSeconds: 600,
    audioFilePath: '/recordings/call-001.m4a',
    transcript: 'Hey, did you get a chance to review the proposal I sent over? We should discuss the quarterly numbers before the board meeting.',
    summary: 'Sarah called to discuss the quarterly proposal and board meeting preparation.',
    tags: ['business', 'urgent'],
    isFavorite: true,
    sourceMethod: 'system',
  },
  {
    id: '2',
    callId: 'call-002',
    phoneNumber: '+1 (555) 987-6543',
    contactName: 'James Rodriguez',
    direction: 'outgoing',
    startTime: new Date(Date.now() - 86400000),
    endTime: new Date(Date.now() - 85800000),
    durationSeconds: 420,
    audioFilePath: '/recordings/call-002.m4a',
    transcript: 'The contract has been finalized and our legal team has approved all the terms. We can proceed with the signing tomorrow.',
    summary: 'James confirmed contract finalization and scheduling for signing ceremony.',
    tags: ['legal', 'contract'],
    isFavorite: false,
    sourceMethod: 'system',
  },
  {
    id: '3',
    callId: 'call-003',
    phoneNumber: '+1 (555) 456-7890',
    contactName: null,
    direction: 'incoming',
    startTime: new Date(Date.now() - 172800000),
    endTime: new Date(Date.now() - 172200000),
    durationSeconds: 180,
    audioFilePath: '/recordings/call-003.m4a',
    transcript: 'This is a follow-up on your insurance claim. The documents have been processed and you should receive the check within five business days.',
    summary: 'Insurance claim processing update - payment arriving within 5 business days.',
    tags: ['insurance'],
    isFavorite: false,
    sourceMethod: 'both',
  },
  {
    id: '4',
    callId: 'call-004',
    phoneNumber: '+1 (555) 246-8135',
    contactName: 'Emily Chen',
    direction: 'outgoing',
    startTime: new Date(Date.now() - 259200000),
    endTime: new Date(Date.now() - 258720000),
    durationSeconds: 480,
    audioFilePath: '/recordings/call-004.m4a',
    transcript: 'The product launch is scheduled for next month. Marketing has prepared all the materials and the team is ready for the presentation.',
    summary: 'Product launch coordination - all materials ready for next month presentation.',
    tags: ['marketing', 'launch'],
    isFavorite: true,
    sourceMethod: 'system',
  },
  {
    id: '5',
    callId: 'call-005',
    phoneNumber: '+1 (555) 369-2580',
    contactName: 'Unknown',
    direction: 'incoming',
    startTime: new Date(Date.now() - 345600000),
    endTime: new Date(Date.now() - 345000000),
    durationSeconds: 60,
    audioFilePath: '/recordings/call-005.m4a',
    transcript: 'Please hold for the next available representative. Your estimated wait time is approximately three minutes.',
    summary: 'Spam/solicitation call - auto-attendant message.',
    tags: ['spam'],
    isFavorite: false,
    sourceMethod: 'microphone',
  },
];
