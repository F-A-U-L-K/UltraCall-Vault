package com.ultracall.vault.services;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;

public class CallReceiver extends BroadcastReceiver {
    private static final String TAG = "UltraCall";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        
        if (TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(action)) {
            String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
            
            if (TelephonyManager.EXTRA_STATE_RINGING.equals(state)) {
                String incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
                Log.d(TAG, "Incoming call from: " + incomingNumber);
                startRecording(context, "incoming", incomingNumber);
            } else if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state)) {
                Log.d(TAG, "Call active");
            } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(state)) {
                Log.d(TAG, "Call ended");
                stopRecording(context);
            }
        } else if (Intent.ACTION_NEW_OUTGOING_CALL.equals(action)) {
            String outgoingNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
            Log.d(TAG, "Outgoing call to: " + outgoingNumber);
            startRecording(context, "outgoing", outgoingNumber);
        }
    }

    private void startRecording(Context context, String direction, String phoneNumber) {
        Intent recordIntent = new Intent(context, RecordingService.class);
        recordIntent.setAction("START_RECORDING");
        recordIntent.putExtra("direction", direction);
        recordIntent.putExtra("phoneNumber", phoneNumber);
        context.startService(recordIntent);
    }

    private void stopRecording(Context context) {
        Intent recordIntent = new Intent(context, RecordingService.class);
        recordIntent.setAction("STOP_RECORDING");
        context.startService(recordIntent);
    }
}
