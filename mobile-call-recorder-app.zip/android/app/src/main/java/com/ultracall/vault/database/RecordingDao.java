package com.ultracall.vault.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.Date;
import java.util.List;

@Dao
public interface RecordingDao {
    @Insert
    void insert(Recording recording);
    
    @Update
    void update(Recording recording);
    
    @Delete
    void delete(Recording recording);
    
    @Query("SELECT * FROM recordings ORDER BY startTime DESC")
    List<Recording> getAllRecordings();
    
    @Query("SELECT * FROM recordings WHERE id = :id")
    Recording getById(int id);
    
    @Query("SELECT * FROM recordings WHERE phoneNumber = :phone AND startTime > :time LIMIT 1")
    Recording findByPhoneAndTime(String phone, Date time);
    
    @Query("SELECT EXISTS(SELECT 1 FROM recordings WHERE phoneNumber = :phone AND startTime = :time)")
    boolean existsByPhoneAndTime(String phone, Date time);
    
    @Query("DELETE FROM recordings")
    void deleteAll();
}
