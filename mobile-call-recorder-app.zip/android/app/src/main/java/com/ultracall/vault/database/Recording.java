package com.ultracall.vault.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "recordings")
public class Recording {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public String callId;
    public String phoneNumber;
    public String contactName;
    public String direction; // "incoming", "outgoing", "unknown"
    public Date startTime;
    public Date endTime;
    public int durationSeconds;
    public String audioFilePath;
    public String micFallbackPath;
    public String transcript;
    public String tags; // JSON array as string
    public boolean isFavorite;
    public String sourceMethod; // "system", "microphone", "both"
    public String summary;
}
