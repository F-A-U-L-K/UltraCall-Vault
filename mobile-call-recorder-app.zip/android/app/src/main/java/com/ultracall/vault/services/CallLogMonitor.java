package com.ultracall.vault.services;

import android.content.Context;
import android.database.Cursor;
import android.provider.CallLog;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.ultracall.vault.database.AppDatabase;
import com.ultracall.vault.database.Recording;
import java.util.Date;

public class CallLogMonitor {
    public static void startMonitoring(Context context) {
        OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(CallLogWorker.class).build();
        WorkManager.getInstance(context).enqueue(workRequest);
    }

    public static class CallLogWorker extends Worker {
        public CallLogWorker(Context context, WorkerParameters params) {
            super(context, params);
        }

        @Override
        public Result doWork() {
            try {
                readCallLog();
                return Result.success();
            } catch (Exception e) {
                e.printStackTrace();
                return Result.retry();
            }
        }

        private void readCallLog() {
            Context context = getApplicationContext();
            AppDatabase db = AppDatabase.getInstance(context);
            Cursor cursor = context.getContentResolver().query(
                CallLog.Calls.CONTENT_URI, null, null, null,
                CallLog.Calls.DATE + " DESC LIMIT 20"
            );
            
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String phoneNumber = cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
                    String contactName = cursor.getString(cursor.getColumnIndex(CallLog.Calls.CACHED_NAME));
                    int callType = cursor.getInt(cursor.getColumnIndex(CallLog.Calls.TYPE));
                    long callDate = cursor.getLong(cursor.getColumnIndex(CallLog.Calls.DATE));
                    int duration = cursor.getInt(cursor.getColumnIndex(CallLog.Calls.DURATION));
                    String direction = getDirection(callType);

                    if (!db.recordingDao().existsByPhoneAndTime(phoneNumber, new Date(callDate))) {
                        Recording rec = new Recording();
                        rec.phoneNumber = phoneNumber;
                        rec.contactName = contactName;
                        rec.direction = direction;
                        rec.startTime = new Date(callDate);
                        rec.durationSeconds = duration;
                        rec.sourceMethod = "system";
                        db.recordingDao().insert(rec);
                    }
                }
                cursor.close();
            }
        }

        private String getDirection(int callType) {
            if (callType == CallLog.Calls.INCOMING_TYPE) return "incoming";
            if (callType == CallLog.Calls.OUTGOING_TYPE) return "outgoing";
            return "unknown";
        }
    }
}
