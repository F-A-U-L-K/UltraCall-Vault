package com.ultracall.vault.web;

import android.content.Context;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import com.ultracall.vault.MainActivity;
import com.ultracall.vault.database.AppDatabase;
import com.ultracall.vault.database.Recording;
import com.ultracall.vault.services.RecordingService;
import java.util.List;

public class JavaScriptInterface {
    private Context context;
    private AppDatabase db;
    
    public JavaScriptInterface(Context ctx) {
        this.context = ctx;
        this.db = AppDatabase.getInstance(ctx);
    }
    
    @JavascriptInterface
    public String getAllRecordings() {
        List<Recording> recs = db.recordingDao().getAllRecordings();
        StringBuilder json = new StringBuilder("[");
        for (int i = 0; i < recs.size(); i++) {
            Recording r = recs.get(i);
            if (i > 0) json.append(",");
            json.append("{");
            json.append("\"id\":\"").append(r.id).append("\",");
            json.append("\"callId\":\"").append(r.callId != null ? r.callId : "").append("\",");
            json.append("\"phoneNumber\":\"").append(r.phoneNumber != null ? r.phoneNumber : "").append("\",");
            json.append("\"contactName\":\"").append(r.contactName != null ? r.contactName : "").append("\",");
            json.append("\"direction\":\"").append(r.direction != null ? r.direction : "").append("\",");
            json.append("\"durationSeconds\":").append(r.durationSeconds);
            json.append("}");
        }
        json.append("]");
        return json.toString();
    }
    
    @JavascriptInterface
    public void deleteRecording(int id) {
        Recording rec = db.recordingDao().getById(id);
        if (rec != null) {
            db.recordingDao().delete(rec);
        }
    }
    
    @JavascriptInterface
    public void toggleFavorite(int id) {
        Recording rec = db.recordingDao().getById(id);
        if (rec != null) {
            rec.isFavorite = !rec.isFavorite;
            db.recordingDao().update(rec);
        }
    }
    
    @JavascriptInterface
    public void startRecording() {
        Intent intent = new Intent(context, RecordingService.class);
        intent.setAction("START_RECORDING");
        context.startService(intent);
    }
    
    @JavascriptInterface
    public void stopRecording() {
        Intent intent = new Intent(context, RecordingService.class);
        intent.setAction("STOP_RECORDING");
        context.startService(intent);
    }
    
    @JavascriptInterface
    public void updatePermissionStatus(boolean granted) {
        if (context instanceof MainActivity) {
            MainActivity activity = (MainActivity) context;
            activity.runOnUiThread(() -> {
                activity.getWebView().evaluateJavascript(
                    "window.onPermissionUpdate && window.onPermissionUpdate(" + granted + ");",
                    null
                );
            });
        }
    }
}
