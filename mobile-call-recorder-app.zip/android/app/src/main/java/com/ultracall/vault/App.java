package com.ultracall.vault;

import android.app.Application;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // Initialize any app-wide resources here
    }
}
